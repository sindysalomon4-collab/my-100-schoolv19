CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS students (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), full_name text NOT NULL, address text, age integer,
 education_level text, email text NOT NULL UNIQUE, phone text, plan text,
 status text NOT NULL DEFAULT 'pending' CHECK(status IN('pending','approved','rejected')),
 receipt_path text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS lesson_progress (
 student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE, subject text NOT NULL,
 lesson_no integer NOT NULL CHECK(lesson_no BETWEEN 1 AND 100), completed_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(student_id,subject,lesson_no)
);
CREATE TABLE IF NOT EXISTS assessment_results (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 subject text NOT NULL, assessment_type text NOT NULL CHECK(assessment_type IN('quiz','exam')), assessment_id integer NOT NULL,
 score integer NOT NULL CHECK(score BETWEEN 0 AND 100), correct integer NOT NULL, total integer NOT NULL,
 passed boolean NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(student_id,subject,assessment_type,assessment_id)
);
CREATE TABLE IF NOT EXISTS certificates (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 code text NOT NULL UNIQUE, subject text NOT NULL, student_name text NOT NULL, issued_at timestamptz NOT NULL DEFAULT now(),
 honors text NOT NULL, director text NOT NULL
);
CREATE TABLE IF NOT EXISTS worksheets (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), title text NOT NULL, subject text NOT NULL, lesson integer NOT NULL DEFAULT 1,
 instructions text NOT NULL, answer_key text NOT NULL DEFAULT '', created_at timestamptz NOT NULL DEFAULT now(), created_by text
);
CREATE TABLE IF NOT EXISTS lexicon (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), kreyol text NOT NULL, francais text NOT NULL, english text NOT NULL,
 pronunciation text NOT NULL DEFAULT '', notes text NOT NULL DEFAULT '', created_at timestamptz NOT NULL DEFAULT now(), created_by text
);
CREATE TABLE IF NOT EXISTS notifications (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), message text NOT NULL, target text NOT NULL DEFAULT 'approved_students',
 status text NOT NULL DEFAULT 'queued', created_at timestamptz NOT NULL DEFAULT now(), created_by text
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), actor text, actor_role text, action text NOT NULL,
 payload jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_results_student ON assessment_results(student_id);
CREATE INDEX IF NOT EXISTS idx_lesson_student ON lesson_progress(student_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
