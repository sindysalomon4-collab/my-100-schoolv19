import pg from 'pg';
const {Pool}=pg;
export const hasDatabase=Boolean(process.env.DATABASE_URL);
export const pool=hasDatabase?new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_SSL==='false'?false:{rejectUnauthorized:false},max:Number(process.env.DATABASE_POOL_SIZE||10)}):null;
export async function query(text,params=[]){if(!pool)throw new Error('DATABASE_URL is not configured');return pool.query(text,params)}
export async function initDb(){if(!pool)return; await query(`CREATE EXTENSION IF NOT EXISTS pgcrypto`);}
