# My 100 School v14

v14 makes PostgreSQL the actual source of truth for production data rather than a prepared schema only.

## Main changes
- PostgreSQL-backed students, approval status, receipts, lesson completion, assessment results, certificates, worksheets, lexicon, notifications, and audit logs.
- Assessment scores are calculated on the server from answer keys.
- Lesson completion is stored per student and survives API restarts.
- Certificate records are persistent and have unique verification codes.
- Admin and student access remains server-side role protected.
- Payment receipt files remain outside the public frontend and are served only after authentication.
- PWA/mobile features and the AI Teacher voice layer from v13 remain included.

## Run locally
1. Copy `.env.example` to `.env` and set a strong `JWT_SECRET`.
2. Start PostgreSQL: `docker compose up -d`.
3. Apply `db/schema.sql` to the `my100school` database.
4. Set `DATABASE_URL`.
5. Install packages: `npm install`.
6. Start: `npm run dev`.

For production, use managed PostgreSQL, HTTPS, a secrets manager, private object storage for receipts, malware scanning, backups, rate limiting, and a real push provider.
